<?php

return [

    'driver'   => 'phpmailer',
    'phpmailer' => [
        'host'     => 'smtpdm.aliyun.com',
        'port'     => '80',
        'name'     => 'GoPHP官方',
        'user'     => 'php@notice.juzifenqi.cn',
        'password' => 'BKXHES2boewc0A',
        'auth'     => true,
    ],

];


