<?php

namespace gophp\cache\driver;

use gophp\cache\contract;


class memcached
{

    //todo

}