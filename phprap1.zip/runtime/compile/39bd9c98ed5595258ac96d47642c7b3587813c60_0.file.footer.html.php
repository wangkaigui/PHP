<?php
/* Smarty version 3.1.31, created on 2018-09-07 09:47:27
  from "D:\phpStudy\WWW\phprap\application\install\view\public\footer.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5b91d8af6050c5_64718079',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '39bd9c98ed5595258ac96d47642c7b3587813c60' => 
    array (
      0 => 'D:\\phpStudy\\WWW\\phprap\\application\\install\\view\\public\\footer.html',
      1 => 1536283687,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b91d8af6050c5_64718079 (Smarty_Internal_Template $_smarty_tpl) {
?>

</body>

</html><?php }
}
