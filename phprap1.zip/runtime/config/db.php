<?php
return
array (
  'driver' => 'mysql',
  'mysql' => 
  array (
    'host' => 'localhost',
    'port' => '3306',
    'name' => 'phprap',
    'user' => 'root',
    'password' => 'root',
    'prefix' => 'doc_',
    'charset' => 'UTF8',
  ),
)
?>