<?php
/**
 * captcha契约
 */
namespace gophp\captcha;

abstract class contract
{

    protected $config;

}