<?php
//默认配置
return [

    'host'     => '', // 服务器地址
    'port'     => 6379, // 端口号
    'password' => 'YVWHR2ckmcSnyw', // 密码
    'database' => 0,

];


