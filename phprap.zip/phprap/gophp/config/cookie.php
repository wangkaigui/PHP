<?php
//默认配置
return [

    'token'  => '01CVhZIgSogB85WNhwYVk79A==',
    'expire' => 24 * 3600,
    'path'   => '/',
    'domain' => '',
    'secure' => '',

];


