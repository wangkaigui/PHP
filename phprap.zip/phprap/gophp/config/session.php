<?php
//默认SESSION配置
return [

    'driver' => 'file',
    'expire' => 24 * 3600,

];


