<?php
//默认配置
return [

    'app_namespace'     => 'app', // 应用命名空间
    'default_timezone'  => 'PRC', // 默认时区
    'default_charset'   => 'utf-8', // 默认字符编码

];


