<?php
//默认LOG配置
return [

    'save_path' => LOG_PATH,
    'extension' => 'php',
    'format'    => 'Y/m/d',

];


