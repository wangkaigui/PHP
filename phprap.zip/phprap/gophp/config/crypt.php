<?php
//默认配置
return [

    'driver' => 'openssl',
    'openssl' => [
        'token'  => 'RwOtehgT4JC4LxvU',
        'method' => 'AES-256-CBC',
    ],

];


