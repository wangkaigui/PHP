<?php
//默认配置
return [

    'rule' => 'extension'

];
